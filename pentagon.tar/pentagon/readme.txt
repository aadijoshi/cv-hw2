Stereo pair: Aerial view of the Pentagon

Image: 512x512 grayscale

